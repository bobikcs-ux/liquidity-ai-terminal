import React from 'react';
import { TrendingUp, AlertTriangle, Activity, DollarSign } from 'lucide-react';
import { useAdaptiveTheme } from '../context/AdaptiveThemeContext';
import { AICopilot } from '../components/AICopilot';
import { RiskDefenseAI } from '../components/RiskDefenseAI';
import { ResourceShockEngine } from '../components/ResourceShockEngine';
import { ConflictTransmissionModel } from '../components/ConflictTransmissionModel';
import { EmploymentDisruptionLayer } from '../components/EmploymentDisruptionLayer';
import { NarrativeShockModel } from '../components/NarrativeShockModel';
import { ThemeDebugger } from '../components/ThemeDebugger';

export function Dashboard() {
  const { currentRegime, uiTheme } = useAdaptiveTheme();
  const isDark = uiTheme === 'terminal';
  const isHybrid = uiTheme === 'hybrid';
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
        <div>
          <h1 className={`text-3xl font-bold mb-2 ${
            isDark || isHybrid ? 'text-white' : 'text-gray-900'
          }`}>
            Intelligence Dashboard
          </h1>
          <p className={`text-sm ${
            isDark || isHybrid ? 'text-gray-400' : 'text-gray-600'
          }`}>
            Real-time market regime analysis powered by adaptive AI
          </p>
        </div>
      </div>

      {/* Autonomous Risk Defense AI */}
      {currentRegime.riskLevel >= 60 && <RiskDefenseAI />}

      {/* Top Row - Main Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Regime Intelligence Card */}
        <div className={`rounded-xl shadow-sm border p-6 transition-colors duration-500 ${
          isDark ? 'bg-[#1a2332] border-blue-900' : isHybrid ? 'bg-[#242b3d] border-gray-700' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
              isDark ? 'bg-blue-600' : isHybrid ? 'bg-blue-500' : 'bg-[#EFF6FF]'
            }`}>
              <TrendingUp className={`w-5 h-5 ${
                isDark || isHybrid ? 'text-white' : 'text-[#2563EB]'
              }`} />
            </div>
            <h2 className={`text-lg font-semibold ${
              isDark || isHybrid ? 'text-white' : 'text-gray-900'
            }`}>
              Regime Intelligence
            </h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <div className={`text-sm mb-1 ${
                isDark || isHybrid ? 'text-gray-400' : 'text-gray-500'
              }`}>
                Current Regime
              </div>
              <div className={`text-2xl font-bold ${
                isDark || isHybrid ? 'text-white' : 'text-gray-900'
              }`}>
                {currentRegime.regime.charAt(0).toUpperCase() + currentRegime.regime.slice(1)}
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className={`text-xs mb-1 ${
                  isDark || isHybrid ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  Confidence
                </div>
                <div className="text-xl font-semibold text-green-600">
                  {currentRegime.confidence}%
                </div>
              </div>
              <div>
                <div className={`text-xs mb-1 ${
                  isDark || isHybrid ? 'text-gray-400' : 'text-gray-500'
                }`}>
                  Risk Level
                </div>
                <div className={`text-xl font-semibold ${
                  currentRegime.riskLevel > 70 ? 'text-red-500' :
                  currentRegime.riskLevel > 40 ? 'text-amber-500' : 'text-green-600'
                }`}>
                  {currentRegime.riskLevel}%
                </div>
              </div>
            </div>

            <div className={`pt-4 border-t ${
              isDark || isHybrid ? 'border-gray-700' : 'border-gray-100'
            }`}>
              <div className="flex items-center justify-between text-sm">
                <span className={isDark || isHybrid ? 'text-gray-400' : 'text-gray-600'}>
                  Next Review
                </span>
                <span className={`font-medium ${
                  isDark || isHybrid ? 'text-white' : 'text-gray-900'
                }`}>
                  14 hours
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Survival Probability Card */}
        <div className={`rounded-xl shadow-sm border p-6 transition-colors duration-500 ${
          isDark ? 'bg-[#1a2332] border-blue-900' : isHybrid ? 'bg-[#242b3d] border-gray-700' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              isDark ? 'bg-green-700' : isHybrid ? 'bg-green-600' : 'bg-[#F0FDF4]'
            }`}>
              <Activity className={`w-5 h-5 ${
                isDark || isHybrid ? 'text-white' : 'text-green-600'
              }`} />
            </div>
            <h2 className={`text-lg font-semibold ${
              isDark || isHybrid ? 'text-white' : 'text-gray-900'
            }`}>
              Survival Probability
            </h2>
          </div>
          
          <div className="text-center py-6">
            <div className="text-5xl font-bold text-green-600 mb-2">
              {Math.round(94 - currentRegime.riskLevel * 0.3)}%
            </div>
            <p className={`text-sm ${
              isDark || isHybrid ? 'text-gray-400' : 'text-gray-600'
            }`}>
              30-day horizon
            </p>
          </div>

          <select className={`w-full px-4 py-2 border rounded-xl text-sm font-medium ${
            isDark ? 'bg-gray-900 border-gray-700 text-white' :
            isHybrid ? 'bg-gray-800 border-gray-600 text-white' :
            'bg-gray-50 border-gray-200 text-gray-700'
          }`}>
            <option>Balanced Portfolio</option>
            <option>Aggressive Growth</option>
            <option>Conservative</option>
            <option>Custom Allocation</option>
          </select>

          <p className={`text-xs mt-4 leading-relaxed ${
            isDark || isHybrid ? 'text-gray-500' : 'text-gray-500'
          }`}>
            Based on current market regime and historical stress patterns. Updated every 6 hours.
          </p>
        </div>

        {/* Macro Snapshot Card */}
        <div className={`rounded-xl shadow-sm border p-6 transition-colors duration-500 ${
          isDark ? 'bg-[#1a2332] border-blue-900' : isHybrid ? 'bg-[#242b3d] border-gray-700' : 'bg-white border-gray-200'
        }`}>
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              isDark ? 'bg-amber-700' : isHybrid ? 'bg-amber-600' : 'bg-[#FEF3C7]'
            }`}>
              <DollarSign className={`w-5 h-5 ${
                isDark || isHybrid ? 'text-white' : 'text-amber-600'
              }`} />
            </div>
            <h2 className={`text-lg font-semibold ${
              isDark || isHybrid ? 'text-white' : 'text-gray-900'
            }`}>
              Macro Snapshot
            </h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className={`text-sm ${
                isDark || isHybrid ? 'text-gray-400' : 'text-gray-600'
              }`}>
                Real Yield
              </span>
              <span className={`text-lg font-semibold ${
                isDark || isHybrid ? 'text-white' : 'text-gray-900'
              }`}>
                2.34%
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className={`text-sm ${
                isDark || isHybrid ? 'text-gray-400' : 'text-gray-600'
              }`}>
                M2 Momentum
              </span>
              <span className="text-lg font-semibold text-green-600">+3.2%</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className={`text-sm ${
                isDark || isHybrid ? 'text-gray-400' : 'text-gray-600'
              }`}>
                Yield Curve
              </span>
              <span className="text-lg font-semibold text-red-600">-0.23</span>
            </div>

            <div className="flex items-center justify-between">
              <span className={`text-sm ${
                isDark || isHybrid ? 'text-gray-400' : 'text-gray-600'
              }`}>
                VIX Index
              </span>
              <span className={`text-lg font-semibold ${
                isDark || isHybrid ? 'text-white' : 'text-gray-900'
              }`}>
                {currentRegime.volatilityIndex}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Global Resource Shock Engine - Systemic Drivers Panel */}
      <ResourceShockEngine />

      {/* Global Conflict Transmission Model - Systemic Risk Drivers Panel */}
      <ConflictTransmissionModel />

      {/* Structural Employment Disruption Layer - Systemic Drivers Panel */}
      <EmploymentDisruptionLayer />

      {/* Narrative Shock Transmission Model - Systemic Drivers Panel */}
      <NarrativeShockModel />

      {/* Stress Signals Feed */}
      <div className={`rounded-xl shadow-sm border p-6 transition-colors duration-500 ${
        isDark ? 'bg-[#1a2332] border-blue-900' : isHybrid ? 'bg-[#242b3d] border-gray-700' : 'bg-white border-gray-200'
      }`}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              isDark ? 'bg-red-900' : isHybrid ? 'bg-red-800' : 'bg-[#FEF2F2]'
            }`}>
              <AlertTriangle className={`w-5 h-5 ${
                isDark || isHybrid ? 'text-red-400' : 'text-red-600'
              }`} />
            </div>
            <h2 className={`text-lg font-semibold ${
              isDark || isHybrid ? 'text-white' : 'text-gray-900'
            }`}>
              Stress Signals Feed
            </h2>
          </div>
          <button className={`text-sm font-medium transition-colors ${
            isDark || isHybrid ? 'text-blue-400 hover:text-blue-300' : 'text-[#2563EB] hover:text-[#1d4ed8]'
          }`}>
            View All
          </button>
        </div>

        <div className="space-y-3">
          {[
            {
              time: '2 hours ago',
              level: 'Medium',
              color: 'amber',
              message: 'Credit spread widening detected in BBB corporates',
            },
            {
              time: '5 hours ago',
              level: 'Low',
              color: 'green',
              message: 'Liquidity conditions improving in USD funding markets',
            },
            {
              time: '8 hours ago',
              level: 'Medium',
              color: 'amber',
              message: 'Cross-asset correlation spike: Equities & Treasuries',
            },
            {
              time: '12 hours ago',
              level: 'High',
              color: 'red',
              message: 'Volatility expansion probability increased to 68%',
            },
          ].map((signal, index) => (
            <div
              key={index}
              className={`flex items-start gap-4 p-4 rounded-2xl transition-colors ${
                isDark ? 'bg-gray-900/50 hover:bg-gray-900/70' :
                isHybrid ? 'bg-gray-800/50 hover:bg-gray-800/70' :
                'bg-gray-50 hover:bg-gray-100'
              }`}
            >
              <div className={`w-2 h-2 rounded-full mt-2 ${
                signal.color === 'red' ? 'bg-red-500' :
                signal.color === 'amber' ? 'bg-amber-500' : 'bg-green-500'
              }`}></div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                    signal.color === 'red' ? 'bg-red-100 text-red-700' :
                    signal.color === 'amber' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'
                  }`}>
                    {signal.level}
                  </span>
                  <span className={`text-xs ${
                    isDark || isHybrid ? 'text-gray-500' : 'text-gray-500'
                  }`}>
                    {signal.time}
                  </span>
                </div>
                <p className={`text-sm ${
                  isDark || isHybrid ? 'text-gray-300' : 'text-gray-900'
                }`}>
                  {signal.message}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* AI Copilot Component */}
      <AICopilot />
      
      {/* Theme Debugger (for demo purposes) */}
      <ThemeDebugger />
    </div>
  );
}