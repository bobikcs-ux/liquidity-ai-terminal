
  # liquidity-ai-v1

  This is a code bundle for liquidity-ai-v1. The original project is available at https://www.figma.com/design/YhKtpk6Mumlq0RdWWH90lg/liquidity-ai-v1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  